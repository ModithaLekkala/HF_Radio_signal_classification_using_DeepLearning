import csv
import re
import numpy as np
from sklearn.preprocessing import LabelEncoder, OneHotEncoder

csv_filename = 'combined_dataset_1695637368.csv'
data = []
snr = []
labels_mode = []
desired_snr_values = [-10,-5,0,5,10,15,20,25]  # SNR values to filter
with open(csv_filename, 'r') as csv_file:
    csv_reader = csv.reader(csv_file)
    for row in csv_reader:
        current_snr = float(row[2])  # Extract SNR value from the row
        # Check if the SNR value is in the desired_snr_values list
        if current_snr in desired_snr_values:
            iq_samples = [complex(re.sub(r'[()]', '', value.replace(' ', ''))) for value in row[3:]]
            # Append IQ samples to the data list
            data.append(iq_samples)
            # Append SNR values and labels to respective lists
            snr.append(current_snr)
            labels_mode.append(row[1])
# Convert data to a NumPy array
data = np.array(data)

# Standardizing 'data' using mean and standard deviation
data = (data - np.mean(data, axis=1, keepdims=True)) / np.std(data, axis=1, keepdims=True)  

# Combining real and imaginary parts into a single array
data = np.stack((np.real(data), np.imag(data)), axis=-1)
print(data.shape)

# Encoding categorical labels using LabelEncoder and OneHotEncoder
label_encoder = LabelEncoder()
encoded_labels = label_encoder.fit_transform(labels_mode)
onehot_encoder = OneHotEncoder(sparse=False)
encoded_labels = encoded_labels.reshape(-1, 1)
onehot_labels = onehot_encoder.fit_transform(encoded_labels)

# Dictionary to store indices for each SNR and mode
indices_by_snr_mode = {}
# Populate the dictionary with indices corresponding to SNR and mode
for idx, (current_snr, current_mode) in enumerate(zip(snr, labels_mode)):
    key = (current_snr, current_mode)
    if key not in indices_by_snr_mode:
        indices_by_snr_mode[key] = []
    indices_by_snr_mode[key].append(idx)

# Lists to store indices for training and testing
train_indices = []
test_indices = []
#print(indices_by_snr_mode)
# Select 200 signals for testing for each SNR and mode
for indices_list in indices_by_snr_mode.values():
    test_indices.extend(indices_list[:200])  # Take the first 200 for testing
    train_indices.extend(indices_list[200:])  # Take the remaining for training

# Split the data into training and testing sets based on the selected indices
X_train, X_test = data[train_indices], data[test_indices]
y_train, y_test = onehot_labels[train_indices], onehot_labels[test_indices]

# Check the shapes of the training and testing data
print("X_train shape:", X_train.shape)
print("X_test shape:", X_test.shape)
print("y_train shape:", y_train.shape)
print("y_test shape:", y_test.shape)