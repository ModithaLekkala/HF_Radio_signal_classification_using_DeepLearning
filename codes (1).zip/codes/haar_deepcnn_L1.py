import csv
import re
import pandas as pd
import numpy as np
import cv2
import pickle
import scipy
import h5py
import json
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.signal import stft
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, models
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelBinarizer
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import confusion_matrix

csv_filename = 'combined_dataset_1695637368.csv'
data = []
snr = []
labels_mode = []
desired_snr_values = [-10,-5,0,5,10,15,20,25] # SNR values to filter
with open(csv_filename, 'r') as csv_file:
    csv_reader = csv.reader(csv_file)
    for row in csv_reader:
        current_snr = float(row[2])  # Extract SNR value from the row
        # Check if the SNR value is in the desired_snr_values list
        if current_snr in desired_snr_values:
            iq_samples = [complex(re.sub(r'[()]', '', value.replace(' ', ''))) for value in row[3:]]
            data.append(iq_samples)
            # Append SNR values and labels to respective lists
            snr.append(current_snr)
            labels_mode.append(row[1])
# Convert data to a NumPy array
class_labels = labels_mode
data = np.array(data)
print("orginal data shape:",data.shape)

def haar_wavelet_transform(data):
    output = []
    temp = []
    while len(data) > 1:
        for i in range(0, len(data), 2):
            avg = (data[i] + data[i+1]) / 2
            diff = data[i] - avg
            temp.append(avg)
            output.append(diff)
        data = temp
        temp = []
    output.append(data[0])
    return output

# Apply the Haar wavelet transform to each row in the data
data = np.array([haar_wavelet_transform(row) for row in data])
print("Transformed data shape:", data.shape)
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
# Preprocess the haar wavelet features
# Normalize the data to have zero mean and unit variance
data = (data - np.mean(data, axis=1, keepdims=True)) / np.std(data, axis=1, keepdims=True)
real_part = np.real(data)
imaginary_part = np.imag(data)
# Reshape real and imaginary parts for CNN input (assuming you want to keep samples together)
data = np.stack((real_part, imaginary_part), axis=-1)
# Check the shape of the combined data
print(data.shape)

label_encoder = LabelEncoder()
encoded_labels = label_encoder.fit_transform(labels_mode)
# Convert encoded labels to one-hot vectors
onehot_encoder = OneHotEncoder(sparse=False)
encoded_labels = encoded_labels.reshape(-1, 1)
onehot_labels = onehot_encoder.fit_transform(encoded_labels)
# Dictionary to store indices for each SNR and mode
indices_by_snr_mode = {}
# Populate the dictionary with indices corresponding to SNR and mode
for idx, (current_snr, current_mode) in enumerate(zip(snr, labels_mode)):
    key = (current_snr, current_mode)
    if key not in indices_by_snr_mode:
        indices_by_snr_mode[key] = []
    indices_by_snr_mode[key].append(idx)

# Lists to store indices for training and testing
train_indices = []
test_indices = []
# Select 20 signals for testing for each SNR and mode
for indices_list in indices_by_snr_mode.values():
    test_indices.extend(indices_list[:200])  # Take the first 20 for testing
    train_indices.extend(indices_list[200:])  # Take the remaining for training

# Split the data into training and testing sets based on the selected indices
X_train, X_test = data[train_indices],data[test_indices]
y_train, y_test = onehot_labels[train_indices], onehot_labels[test_indices]
# Check the shapes of the training and testing data

print("X_train shape:", X_train.shape)
print("X_test shape:", X_test.shape)
print("y_train shape:", y_train.shape)
print("y_test shape:", y_test.shape)

model = models.Sequential()
# Layer 1
model.add(layers.Conv1D(32, 3, activation='relu', input_shape=(2048,2), padding='same'))
model.add(layers.BatchNormalization())
model.add(layers.Conv1D(32, 3, activation='relu', padding='same'))
model.add(layers.BatchNormalization())
model.add(layers.MaxPooling1D(pool_size=2))
# Layer 2
model.add(layers.Conv1D(32, 3, activation='relu', padding='same'))
model.add(layers.BatchNormalization())
model.add(layers.Conv1D(32, 3, activation='relu', padding='same'))
model.add(layers.BatchNormalization())
model.add(layers.MaxPooling1D(pool_size=2))
# Layer 3
model.add(layers.Conv1D(64, 3, activation='relu', padding='same'))
model.add(layers.BatchNormalization())
model.add(layers.Conv1D(64, 3, activation='relu', padding='same'))
model.add(layers.BatchNormalization())
model.add(layers.MaxPooling1D(pool_size=2))
# Layer 4
model.add(layers.Conv1D(64, 3, activation='relu', padding='same'))
model.add(layers.BatchNormalization())
model.add(layers.Conv1D(64, 3, activation='relu', padding='same'))
model.add(layers.BatchNormalization())
model.add(layers.MaxPooling1D(pool_size=2))
# Layer 5
model.add(layers.Conv1D(128, 3, activation='relu', padding='same'))
model.add(layers.BatchNormalization())
model.add(layers.Conv1D(128, 3, activation='relu', padding='same'))
model.add(layers.BatchNormalization())
# Flatten the output
model.add(layers.Flatten())
# Additional Dense Layers
model.add(layers.Dense(512, activation='relu'))
model.add(layers.Dropout(0.5))
# Output Layer for AMR classification
model.add(layers.Dense(18, activation='softmax'))  # 'num_classes' is the number of modulation classes
# Compile the model
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
# Print model summary
model.summary()
# Train the model
history1 = model.fit(X_train, y_train, epochs=20, batch_size=32, validation_data=(X_test, y_test))
# Evaluate the model
test_loss, test_accuracy = model.evaluate(X_test, y_test)
print(f'Test accuracy: {test_accuracy}')

# Plot training and validation accuracy
plt.figure(figsize=(10, 5))
plt.plot(history1.history['accuracy'], label='Training Accuracy')
plt.plot(history1.history['val_accuracy'], label='Validation Accuracy')
plt.title('Training and Validation Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()
plt.savefig('training_validation_accuracy_plot.png')
#plt.show()

# Predictions on the test set
y_pred = model.predict(X_test)
y_pred_classes = np.argmax(y_pred, axis=1)
y_true_classes = np.argmax(y_test, axis=1)

# Extract SNR values for each test sample
snr_test = [snr[idx] for idx in test_indices]

# Dictionary to store confusion matrices for each SNR
confusion_matrices_by_snr = {}

# Generate confusion matrices for each SNR level
for current_snr in set(snr_test):
    indices_for_snr = [i for i, snr_value in enumerate(snr_test) if snr_value == current_snr]
    cm = confusion_matrix(y_true_classes[indices_for_snr], y_pred_classes[indices_for_snr])
    confusion_matrices_by_snr[current_snr] = cm

# Plot confusion matrices for each SNR
for snr_value, confusion_matrix_snr in confusion_matrices_by_snr.items():
    # Convert confusion matrix to percentage
    cm_percentage = confusion_matrix_snr / confusion_matrix_snr.sum(axis=1, keepdims=True) * 100

    plt.figure(figsize=(16, 14))
    sns.heatmap(cm_percentage, annot=True, fmt='.2f', cmap='Blues', xticklabels=label_encoder.classes_, yticklabels=label_encoder.classes_)
    plt.title(f'Confusion Matrix for SNR {snr_value}')
    plt.xlabel('Predicted Label (%)')
    plt.ylabel('True Label')
    plt.savefig(f'confusion_matrix_snr_{snr_value}.png')
    #plt.show()

# Accuracy vs. SNR
accuracy_per_snr = []
for snr_value, confusion_matrix_snr in confusion_matrices_by_snr.items():
    correct_predictions = np.trace(confusion_matrix_snr)
    total_predictions = np.sum(confusion_matrix_snr)
    accuracy = correct_predictions / total_predictions
    accuracy_per_snr.append((snr_value, accuracy))

# Sort by SNR value
accuracy_per_snr.sort(key=lambda x: x[0])

# Extract SNR values and accuracies
snr_values = [x[0] for x in accuracy_per_snr]
accuracies = [x[1]*100 for x in accuracy_per_snr]

# Plot Accuracy vs. SNR
plt.figure(figsize=(10, 6))
plt.plot(snr_values, accuracies, marker='o', linestyle='-')
plt.title('Accuracy vs. SNR')
plt.xlabel('SNR (dB)')
plt.ylabel('Accuracy')
plt.grid(True)
plt.savefig('accuracy_vs_snr_plot.png')

# Save the trained model to an HDF5 file
model.save('trained_model.h5')
