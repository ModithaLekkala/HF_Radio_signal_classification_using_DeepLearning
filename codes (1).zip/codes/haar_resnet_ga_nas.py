import csv
import re
import pandas as pd
import numpy as np
import cv2
import pickle
import scipy
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.signal import stft
import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.utils import plot_model
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelBinarizer
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import StandardScaler, LabelEncoder
from keras import datasets
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.layers import Conv1D, Dense, Flatten, MaxPooling1D, Dropout, GlobalAveragePooling1D
from random import choice
from random import uniform
from numpy.random import randint
from sklearn.metrics import confusion_matrix
import seaborn as sns

csv_filename = 'combined_dataset_1695637368.csv'
data = []
snr = []
labels_mode = []
desired_snr_values = [-10,-5,0,5,10,15,20,25] # SNR values to filter
with open(csv_filename, 'r') as csv_file:
    csv_reader = csv.reader(csv_file)
    for row in csv_reader:
        current_snr = float(row[2])  # Extract SNR value from the row
        # Check if the SNR value is in the desired_snr_values list
        if current_snr in desired_snr_values:
            iq_samples = [complex(re.sub(r'[()]', '', value.replace(' ', ''))) for value in row[3:]]
            data.append(iq_samples)
            # Append SNR values and labels to respective lists
            snr.append(current_snr)
            labels_mode.append(row[1])
# Convert data to a NumPy array
class_labels = labels_mode
data = np.array(data)
print("orginal data shape:",data.shape)

def haar_wavelet_transform_level_2(data):
    output = []
    temp = []
    level = 0
    while len(data) > 1 and level < 2:
        for i in range(0, len(data), 2):
            avg = (data[i] + data[i+1]) / 2
            diff = data[i] - avg
            temp.append(avg)
            output.append(diff)
        data = temp
        temp = []
        level += 1
    output.extend(data)
    return output

# Apply the level 2 Haar wavelet transform to each row in the data
data = np.array([haar_wavelet_transform_level_2(row) for row in data])
print("Transformed data shape:", data.shape)

import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
# Preprocess the haar wavelet features
# Normalize the data to have zero mean and unit variance
data = (data - np.mean(data, axis=1, keepdims=True)) / np.std(data, axis=1, keepdims=True)
real_part = np.real(data)
imaginary_part = np.imag(data)
# Reshape real and imaginary parts for CNN input (assuming you want to keep samples together)
data = np.stack((real_part, imaginary_part), axis=-1)
# Check the shape of the combined data
print(data.shape)

label_encoder = LabelEncoder()
encoded_labels = label_encoder.fit_transform(labels_mode)
# Convert encoded labels to one-hot vectors
onehot_encoder = OneHotEncoder(sparse=False)
encoded_labels = encoded_labels.reshape(-1, 1)
onehot_labels = onehot_encoder.fit_transform(encoded_labels)
# Dictionary to store indices for each SNR and mode
indices_by_snr_mode = {}
# Populate the dictionary with indices corresponding to SNR and mode
for idx, (current_snr, current_mode) in enumerate(zip(snr, labels_mode)):
    key = (current_snr, current_mode)
    if key not in indices_by_snr_mode:
        indices_by_snr_mode[key] = []
    indices_by_snr_mode[key].append(idx)

# Lists to store indices for training and testing
train_indices = []
test_indices = []
# Select 20 signals for testing for each SNR and mode
for indices_list in indices_by_snr_mode.values():
    test_indices.extend(indices_list[:200])  # Take the first 20 for testing
    train_indices.extend(indices_list[200:])  # Take the remaining for training

# Split the data into training and testing sets based on the selected indices
X_train, X_test = data[train_indices],data[test_indices]
y_train, y_test = onehot_labels[train_indices], onehot_labels[test_indices]
# Check the shapes of the training and testing data

print("X_train shape:", X_train.shape)
print("X_test shape:", X_test.shape)
print("y_train shape:", y_train.shape)
print("y_test shape:", y_test.shape)

from random import randint, choice
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models

# Function to initialize parameters for the genetic algorithm
def initialize_parameters():
    return {
        "filter_sizes": [randint(3, 5) for _ in range(5)],  # Random kernel sizes for each residual block
        "num_filters": [choice([32, 64, 128]) for _ in range(5)],  # Random number of filters for each block
        "dropout_rate": choice([0.1, 0.3, 0.5]),
        "learning_rate": choice([0.001, 0.01, 0.1]),
        "batch_size": choice([64, 128])
    }

# Function to create a model based on the parameters
def create_model(filter_sizes, num_filters, dropout_rate, learning_rate, batch_size):
    input_shape = (2048, 2)
    input_tensor = layers.Input(shape=input_shape)
    x = input_tensor
    for i in range(5):  # Iterate over 5 residual blocks
        x = residual_block(x, num_filters[i], filter_sizes[i])
    x = layers.Dropout(dropout_rate)(x)
    x = layers.GlobalAveragePooling1D()(x)
    x = layers.Dense(18, activation='softmax')(x)
    model = models.Model(input_tensor, x)
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate),
                  loss='categorical_crossentropy', metrics=['accuracy'])
    return model

def residual_block(x, filters, kernel_size):
    shortcut = x
    x = layers.Conv1D(filters, kernel_size, padding='same')(x)
    x = layers.BatchNormalization()(x)
    x = layers.ReLU()(x)
    x = layers.Conv1D(filters, kernel_size, padding='same')(x)
    x = layers.BatchNormalization()(x)
    if x.shape[-1] != shortcut.shape[-1]:  # Adjust shortcut connection if necessary
        shortcut = layers.Conv1D(filters, 1, padding='same')(shortcut)
    x = layers.Add()([x, shortcut])
    x = layers.ReLU()(x)
    return x

def select_parents(weights):
    total = sum(weights)
    probabilities = [weight / total for weight in weights]
    parents_indices = np.random.choice(range(len(weights)), size=2, p=probabilities)
    return parents_indices

def crossover(parents, population):
    parent1 = population[parents[0]]
    parent2 = population[parents[1]]

    child1, child2 = {}, {}

    for key in parent1.keys():
        if np.random.rand() < 0.5:
            child1[key] = parent1[key]
            child2[key] = parent2[key]
        else:
            child1[key] = parent2[key]
            child2[key] = parent1[key]

    return [child1, child2]

def mutation(child):
    if np.random.rand() < 0.35:
        if np.random.rand() < 0.5:
            child["num_filters"] = [num_filters + randint(-16, 16) for num_filters in child["num_filters"]]
        else:
            child["dropout_rate"] = np.random.uniform(0.3, 0.5)
    return child

# Hyperparameters
population_size = 8
generations = 3

# Initialize the population
population = [initialize_parameters() for _ in range(population_size)]

# Genetic algorithm loop
for generation in range(generations):
    weights = []
    for idx, individual in enumerate(population):
        model = create_model(**individual)
        history = model.fit(X_train, y_train, epochs=20, batch_size=75, validation_data=(X_test, y_test), verbose=0)
        score = history.history['val_accuracy'][-1]  # Get the final validation accuracy
        weights.append(score)
        print(f"Generation {generation+1}, Individual {idx+1}: {individual}, Validation Accuracy: {score * 100:.2f}%")

    print("Generation {}: Best Accuracy - {:.2f}%".format(generation+1, max(weights) * 100))

    parents_indices = select_parents(weights)
    children = crossover(parents_indices, population)
    population = [mutation(child) for child in children]

best_individual = population[np.argmax(weights)]
best_model = create_model(**best_individual)
history = best_model.fit(X_train, y_train, epochs=25, batch_size=75, validation_data=(X_test, y_test), verbose=1)
train_accuracy = best_model.evaluate(X_train, y_train, verbose=0)[1]
test_accuracy = best_model.evaluate(X_test, y_test, verbose=0)[1]

print("\nBest Model Parameters:")
for key, value in best_individual.items():
    print(f"{key}: {value}")

print("\nBest Model - Training Accuracy: {:.2f}% | Testing Accuracy: {:.2f}%".format(train_accuracy * 100, test_accuracy * 100))
# Function to calculate MACs and FLOPs
def calculate_macs_flops(model):
    macs = 0
    flops = 0

    for layer in model.layers:
        if isinstance(layer, tf.keras.layers.Conv1D):
            # Calculate MACs for Conv1D layer
            macs += layer.filters * layer.kernel_size[0] * layer.input_shape[-1] * layer.output_shape[-1]

            # Calculate FLOPs for Conv1D layer (assuming 2 FLOPs per MAC)
            flops += 2 * macs

        elif isinstance(layer, tf.keras.layers.Dense):
            # Calculate MACs for Dense layer
            macs += layer.input_shape[-1] * layer.units

            # Calculate FLOPs for Dense layer (assuming 2 FLOPs per MAC)
            flops += 2 * macs

    return macs, flops

# Call the function to get MACs and FLOPs
macs, flops = calculate_macs_flops(best_model)

print(f"MACs: {macs}")
print(f"FLOPs: {flops}")

# Function to calculate total number of nodes and edges
def calculate_nodes_edges(model):
    # Get the model summary
    model.summary()

    # Count the total number of nodes
    total_nodes = sum([layer.count_params() for layer in model.layers])

    # Count the total number of edges
    # Assuming a fully connected layer connects every node from the previous layer to every node in the current layer
    total_edges = sum([layer.input_shape[-1] * layer.units for layer in model.layers if isinstance(layer, tf.keras.layers.Dense)])

    return total_nodes, total_edges

# Call the function to get total number of nodes and edges
total_nodes, total_edges = calculate_nodes_edges(best_model)

print(f"Total Number of Nodes: {total_nodes}")
print(f"Total Number of Edges: {total_edges}")

# Plot training and validation accuracy
plt.figure(figsize=(20, 12))
plt.plot(history.history['accuracy'], label='Training Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title('Training and Validation Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()
plt.savefig('training_validation_accuracy_plot.png')
#plt.show()

# Predictions on the test set
y_pred = best_model.predict(X_test)
y_pred_classes = np.argmax(y_pred, axis=1)
y_true_classes = np.argmax(y_test, axis=1)

# Extract SNR values for each test sample
snr_test = [snr[idx] for idx in test_indices]

# Dictionary to store confusion matrices for each SNR
confusion_matrices_by_snr = {}

# Generate confusion matrices for each SNR level
for current_snr in set(snr_test):
    indices_for_snr = [i for i, snr_value in enumerate(snr_test) if snr_value == current_snr]
    cm = confusion_matrix(y_true_classes[indices_for_snr], y_pred_classes[indices_for_snr])
    confusion_matrices_by_snr[current_snr] = cm

# Plot confusion matrices for each SNR
for snr_value, confusion_matrix_snr in confusion_matrices_by_snr.items():
    plt.figure(figsize=(20, 18))
    sns.heatmap(confusion_matrix_snr, annot=True, fmt='d', cmap='Blues', xticklabels=label_encoder.classes_, yticklabels=label_encoder.classes_)
    plt.title(f'Confusion Matrix for SNR {snr_value}')
    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')
    plt.savefig(f'confusion_matrix_snr_{snr_value}.png')  # Save the plot
    #plt.show()

# Accuracy vs. SNR
accuracy_per_snr = []
for snr_value, confusion_matrix_snr in confusion_matrices_by_snr.items():
    correct_predictions = np.trace(confusion_matrix_snr)
    total_predictions = np.sum(confusion_matrix_snr)
    accuracy = correct_predictions / total_predictions
    accuracy_per_snr.append((snr_value, accuracy))

# Sort by SNR value
accuracy_per_snr.sort(key=lambda x: x[0])

# Extract SNR values and accuracies
snr_values = [x[0] for x in accuracy_per_snr]
accuracies = [x[1]*100 for x in accuracy_per_snr]

# Plot Accuracy vs. SNR
plt.figure(figsize=(20, 12))
plt.plot(snr_values, accuracies, marker='o', linestyle='-')
plt.title('Accuracy vs. SNR')
plt.xlabel('SNR (dB)')
plt.ylabel('Accuracy')
plt.grid(True)
plt.savefig('accuracy_vs_snr_plot.png')
#plt.show()

# Save the trained model to an HDF5 file
best_model.save('Haar_NAS_trained_resnet_model.h5')
