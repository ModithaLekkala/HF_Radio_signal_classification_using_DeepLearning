import csv
import re  # for converting IQ samples from string to complex format
import pandas as pd
import numpy as np
import cv2
import seaborn as sns
import scipy
import matplotlib.pyplot as plt
from scipy.signal import stft
import tensorflow as tf
from tensorflow.keras import layers, models
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelBinarizer
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import StandardScaler, LabelEncoder
csv_filename = 'combined_dataset_1695637368.csv'
data = []
snr = []
labels_mode = []
desired_snr_values = [-10,-5,0,5,10,15,20,25]  # SNR values to filter
with open(csv_filename, 'r') as csv_file:
    csv_reader = csv.reader(csv_file)
    for row in csv_reader:
        current_snr = float(row[2])  # Extract SNR value from the row
        # Check if the SNR value is in the desired_snr_values list
        if current_snr in desired_snr_values:
            iq_samples = [complex(re.sub(r'[()]', '', value.replace(' ', ''))) for value in row[3:]]
            # Append IQ samples to the data list
            data.append(iq_samples)
            # Append SNR values and labels to respective lists
            snr.append(current_snr)
            labels_mode.append(row[1])
# Convert data to a NumPy array
data = np.array(data)
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, OneHotEncoder

# Standardizing 'data' using mean and standard deviation
data = (data - np.mean(data, axis=1, keepdims=True)) / np.std(data, axis=1, keepdims=True) 

data = np.stack((np.real(data), np.imag(data)), axis=-1)

print(data.shape)

# Encoding categorical labels using LabelEncoder and OneHotEncoder
label_encoder = LabelEncoder()
encoded_labels = label_encoder.fit_transform(labels_mode)
onehot_encoder = OneHotEncoder(sparse=False)
encoded_labels = encoded_labels.reshape(-1, 1)
onehot_labels = onehot_encoder.fit_transform(encoded_labels)
# Dictionary to store indices for each SNR and mode
indices_by_snr_mode = {}
# Populate the dictionary with indices corresponding to SNR and mode
for idx, (current_snr, current_mode) in enumerate(zip(snr, labels_mode)):
    key = (current_snr, current_mode)
    if key not in indices_by_snr_mode:
        indices_by_snr_mode[key] = []
    indices_by_snr_mode[key].append(idx)

# Lists to store indices for training and testing
train_indices = []
test_indices = []
#print(indices_by_snr_mode)
# Select 200 signals for testing for each SNR and mode
for indices_list in indices_by_snr_mode.values():
    test_indices.extend(indices_list[:200])  # Take the first 200 for testing
    train_indices.extend(indices_list[200:])  # Take the remaining for training

# Split the data into training and testing sets based on the selected indices
X_train, X_test = data[train_indices], data[test_indices]
y_train, y_test = onehot_labels[train_indices], onehot_labels[test_indices]
# Check the shapes of the training and testing data

print("X_train shape:", X_train.shape)
print("X_test shape:", X_test.shape)
print("y_train shape:", y_train.shape)
print("y_test shape:", y_test.shape)

import numpy as np
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
from tensorflow.keras.models import load_model

# Load the model
model = load_model('trained_resnet_model.h5')

# Use the model to predict labels for the testing data
y_pred = model.predict(X_test)

# Convert one-hot encoded labels back to class labels
y_test_labels = np.argmax(y_test, axis=1)
y_pred_labels = np.argmax(y_pred, axis=1)

# Generate confusion matrix
conf_matrix = confusion_matrix(y_test_labels, y_pred_labels)

# Get class names from label encoder
class_names = label_encoder.classes_

# Plot confusion matrix with class names as labels
plt.figure(figsize=(20, 18))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=class_names, yticklabels=class_names)
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.title('Confusion Matrix')
plt.show()
plt.savefig("confusion_matrix_CNN.png") 

from sklearn.metrics import classification_report

# Generate classification report
class_report = classification_report(y_test_labels, y_pred_labels, target_names=class_names)

# Print classification report
print("Classification Report:\n", class_report)

train_accuracy = model.evaluate(X_train, y_train, verbose=0)[1]
test_accuracy = model.evaluate(X_test, y_test, verbose=0)[1]

print("\nNAS Deep CNN Model based on IQ samples - Training Accuracy: {:.2f}% | Testing Accuracy: {:.2f}%".format(train_accuracy * 100, test_accuracy * 100))

