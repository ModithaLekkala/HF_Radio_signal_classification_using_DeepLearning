import csv
import re  # for converting IQ samples from string to complex format
import pandas as pd
import numpy as np
import cv2
import os
import seaborn as sns
import scipy
import matplotlib.pyplot as plt
from scipy.signal import stft
import tensorflow as tf
from tensorflow.keras import layers, models
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelBinarizer
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import StandardScaler, LabelEncoder
from tensorflow.keras.utils import to_categorical

csv_filename = 'combined_dataset_1695637368.csv'
data = []
snr = []
labels_mode = []
desired_snr_values = [-10,-5,0,5,10,15,20,25]  # SNR values to filter
with open(csv_filename, 'r') as csv_file:
    csv_reader = csv.reader(csv_file)
    for row in csv_reader:
        current_snr = float(row[2])  # Extract SNR value from the row
        # Check if the SNR value is in the desired_snr_values list
        if current_snr in desired_snr_values:
            iq_samples = [complex(re.sub(r'[()]', '', value.replace(' ', ''))) for value in row[3:]]
            # Append IQ samples to the data list
            data.append(iq_samples)
            # Append SNR values and labels to respective lists
            snr.append(current_snr)
            labels_mode.append(row[1])
# Convert data to a NumPy array
data = np.array(data)
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
# Standardizing 'data' using mean and standard deviation
data = (data - np.mean(data, axis=1, keepdims=True)) / np.std(data, axis=1, keepdims=True)    #line 6 to 9 into a single line
# Separating real and imaginary parts of the standardized data
real_part = np.real(data)
imaginary_part = np.imag(data)
# Combining real and imaginary parts into a single array
combined_data = np.stack((real_part, imaginary_part), axis=-1)
print(combined_data.shape)
# Encoding categorical labels using LabelEncoder and OneHotEncoder
label_encoder = LabelEncoder()
encoded_labels = label_encoder.fit_transform(labels_mode)
onehot_encoder = OneHotEncoder(sparse=False)
encoded_labels = encoded_labels.reshape(-1, 1)
onehot_labels = onehot_encoder.fit_transform(encoded_labels)
# Dictionary to store indices for each SNR and mode
indices_by_snr_mode = {}
# Populate the dictionary with indices corresponding to SNR and mode
for idx, (current_snr, current_mode) in enumerate(zip(snr, labels_mode)):
    key = (current_snr, current_mode)
    if key not in indices_by_snr_mode:
        indices_by_snr_mode[key] = []
    indices_by_snr_mode[key].append(idx)

# Lists to store indices for training and testing
train_indices = []
test_indices = []
#print(indices_by_snr_mode)
# Select 20 signals for testing for each SNR and mode
for indices_list in indices_by_snr_mode.values():
    test_indices.extend(indices_list[:200])  # Take the first 20 for testing
    train_indices.extend(indices_list[200:])  # Take the remaining for training

# Split the data into training and testing sets based on the selected indices
X_train, X_test = combined_data[train_indices], combined_data[test_indices]
y_train, y_test = onehot_labels[train_indices], onehot_labels[test_indices]
# Check the shapes of the training and testing data

print("X_train shape:", X_train.shape)
print("X_test shape:", X_test.shape)
print("y_train shape:", y_train.shape)
print("y_test shape:", y_test.shape)

# Split the data into training and testing sets
# You should load and preprocess your data here

# Create a 1D ResNet model
input_shape = (2048, 2)  # Adjust the input shape to match your data

input_tensor = layers.Input(shape=input_shape)

x = input_tensor
x = layers.Conv1D(96, 3, padding='same')(x)
x = layers.BatchNormalization()(x)
x = layers.ReLU()(x)

# Define a function for 1D residual block
def residual_block(x, filters, kernel_size=3):
    shortcut = x
    x = layers.Conv1D(filters, kernel_size, padding='same')(x)
    x = layers.BatchNormalization()(x)
    x = layers.ReLU()(x)
    x = layers.Conv1D(filters, kernel_size, padding='same')(x)
    x = layers.BatchNormalization()(x)
    x = layers.Add()([x, shortcut])
    x = layers.ReLU()(x)
    return x

# Apply residual blocks
for _ in range(5):
    x = residual_block(x, 96)
x = layers.Dropout(0.5)(x)
# Global Average Pooling
x = layers.GlobalAveragePooling1D()(x)
# Dense layer with 3 units for classification
x = layers.Dense(3, activation='softmax')(x)
# Create the model
resnet_model = models.Model(input_tensor, x)
# Compile the model
resnet_model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
# Print a summary of the model architecture
resnet_model.summary()
# Train the model
# You should replace X_train, y_train, X_test, and y_test with your own data
# Also, make sure your data is properly preprocessed and one-hot encoded
history1 = resnet_model.fit(X_train, y_train, epochs=25, batch_size=128, validation_data=(X_test, y_test))
test_loss, test_accuracy = resnet_model.evaluate(X_test, y_test)
print(f'Test accuracy: {test_accuracy}')

# Plot training and validation accuracy
plt.figure(figsize=(20, 15))
plt.plot(history1.history['accuracy'], label='Training Accuracy')
plt.plot(history1.history['val_accuracy'], label='Validation Accuracy')
plt.title('Training and Validation Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()
plt.savefig('training_validation_accuracy_plot.png')
#plt.show()
# Evaluate the model
test_loss, test_accuracy = resnet_model.evaluate(X_test, y_test)
print(f'Test accuracy: {test_accuracy}')

from sklearn.metrics import confusion_matrix

# Predictions on the test set
y_pred = resnet_model.predict(X_test)
y_pred_classes = np.argmax(y_pred, axis=1)
y_true_classes = np.argmax(y_test, axis=1)

# Extract SNR values for each test sample
snr_test = [snr[idx] for idx in test_indices]

# Dictionary to store confusion matrices for each SNR
confusion_matrices_by_snr = {}

# Generate confusion matrices for each SNR level
for current_snr in set(snr_test):
    indices_for_snr = [i for i, snr_value in enumerate(snr_test) if snr_value == current_snr]
    cm = confusion_matrix(y_true_classes[indices_for_snr], y_pred_classes[indices_for_snr])
    confusion_matrices_by_snr[current_snr] = cm

# Plot confusion matrices for each SNR
for snr_value, confusion_matrix_snr in confusion_matrices_by_snr.items():
    # Convert confusion matrix to percentage
    cm_percentage = confusion_matrix_snr / confusion_matrix_snr.sum(axis=1, keepdims=True) * 100
    
    plt.figure(figsize=(20, 18))
    sns.heatmap(cm_percentage, annot=True, fmt='.2f', cmap='Blues', xticklabels=label_encoder.classes_, yticklabels=label_encoder.classes_)
    plt.title(f'Confusion Matrix for SNR {snr_value}')
    plt.xlabel('Predicted Label (%)')
    plt.ylabel('True Label')
    plt.savefig(f'confusion_matrix_snr_{snr_value}.png')  # Save the plot
    #plt.show()
# Accuracy vs. SNR
accuracy_per_snr = []
for snr_value, confusion_matrix_snr in confusion_matrices_by_snr.items():
    correct_predictions = np.trace(confusion_matrix_snr)
    total_predictions = np.sum(confusion_matrix_snr)
    accuracy = correct_predictions / total_predictions
    accuracy_per_snr.append((snr_value, accuracy))

# Sort by SNR value
accuracy_per_snr.sort(key=lambda x: x[0])

# Extract SNR values and accuracies
snr_values = [x[0] for x in accuracy_per_snr]
accuracies = [x[1]*100 for x in accuracy_per_snr]

# Plot Accuracy vs. SNR
plt.figure(figsize=(20, 15))
plt.plot(snr_values, accuracies, marker='o', linestyle='-')
plt.title('Accuracy vs. SNR')
plt.xlabel('SNR (dB)')
plt.ylabel('Accuracy')
plt.grid(True)
plt.savefig('accuracy_vs_snr_plot.png')
#plt.show()
# Save the trained model to an HDF5 file
resnet_model.save('trained_deepcnn_model.h5')